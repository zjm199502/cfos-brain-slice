"""Apple Silicon build updates for FosFolio 0.9.6."""
import platform
import sys
from pathlib import Path

PUBLIC_VERSION = "0.9.6"
QT_VERSION = "6.12.0"
BUILD = 1
CHANNEL = "https://raw.githubusercontent.com/zjm199502/cfos-brain-slice/mac-client-updates/latest.json"


def supports_runtime():
    if sys.platform != "darwin" or platform.machine() != "arm64":
        return False
    from PySide6.QtCore import qVersion
    return qVersion() == QT_VERSION


def configure_plugins():
    if supports_runtime():
        from PySide6.QtCore import QCoreApplication
        root = Path(__file__).resolve().parent / "mac_plugins"
        if (root / "platforms" / "libqcocoa.dylib").is_file():
            QCoreApplication.addLibraryPath(str(root))


def newer_record(public_version, fetch):
    # Give a later regular release precedence over this same-version hotfix.
    if public_version.lstrip("vV") != PUBLIC_VERSION or not supports_runtime():
        return None
    try:
        record = fetch(CHANNEL)
        build = record["mac_build"]
        if (type(build) is int and build > BUILD and record["public_version"] == PUBLIC_VERSION
                and record["version"] == f"{PUBLIC_VERSION}+mac.{build}"
                and record["qt"] == QT_VERSION):
            return record
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None
