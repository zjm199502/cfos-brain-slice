"""Rebuild one arm64 Cocoa plugin with its matching official Qt desktop SDK."""
import argparse
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('product', choices=['FosFolio', 'Miniscope'])
parser.add_argument('sdk', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
qt = args.sdk.resolve()
src = Path(__file__).resolve().parent / args.product / 'src'
mini = args.product == 'Miniscope'
expected = '6.8.3' if mini else '6.12.0'
qmake = qt / 'bin/qmake'
if subprocess.check_output([qmake, '-query', 'QT_VERSION'], text=True).strip() != expected:
    parser.error(f'{args.product} requires the Qt {expected} SDK')
if args.output.exists():
    parser.error('Choose an unused output path')
with tempfile.TemporaryDirectory() as tmp:
    build = Path(tmp)
    subprocess.run([qmake, src/'cocoa.pro'], cwd=build, check=True)
    # The 6.8 SDK still lists AGL, which Xcode 26 removed; Cocoa links OpenGL.
    if mini:
        makefile = build / 'Makefile'
        makefile.write_text(makefile.read_text().replace('-framework AGL ', ''))
    subprocess.run(['make', '-j4'], cwd=build, check=True)
    plugin = build / 'libqcocoa.dylib'
    edits = ['install_name_tool', '-delete_rpath', str(qt/'lib'),
             '-delete_rpath', '@executable_path/../Frameworks', '-add_rpath',
             '@loader_path/../../../..' if mini else '@loader_path/../../lib']
    if mini:
        for lib in ['QtCore', 'QtGui']:
            edits.extend(['-change', f'@rpath/{lib}.framework/Versions/A/{lib}', '@rpath/'+lib])
    subprocess.run([*edits, plugin], check=True)
    subprocess.run(['codesign', '--force', '--sign', '-', plugin], check=True)
    args.output.write_bytes(plugin.read_bytes())
    args.output.chmod(0o755)
