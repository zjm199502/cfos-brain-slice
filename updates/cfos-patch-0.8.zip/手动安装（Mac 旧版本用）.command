#!/bin/bash
# cFos 脑片分析补丁 v0.8：手动安装到已安装的程序里（v0.7 等没有自动更新功能的旧版本用）
D="$(cd "$(dirname "$0")" && pwd)"
A="/Applications/cFos脑片分析.app"
[ -d "$A" ] || A="$HOME/Applications/cFos脑片分析.app"
T="$A/Contents/Resources/app"
if [ ! -f "$T/main.py" ]; then
  echo "没有找到已安装的 cFos脑片分析.app（应在“应用程序”文件夹里）。"
  echo "请把补丁里 app 文件夹中的全部内容复制到：cFos脑片分析.app/Contents/Resources/app/"
  read -r -p "按回车键关闭…"; exit 1
fi
echo "将安装补丁 v0.8 到：$T"
read -r -p "请先退出 cFos 脑片分析，然后按回车键开始…"
if cp -R "$D/app/." "$T/"; then
  echo; echo "补丁已安装，可以打开软件了。以后的更新可以在软件里“帮助 → 检查更新”自动完成。"
else
  echo; echo "复制失败。可以在终端里运行： sudo cp -R \"$D/app/.\" \"$T/\""
fi
read -r -p "按回车键关闭…"
