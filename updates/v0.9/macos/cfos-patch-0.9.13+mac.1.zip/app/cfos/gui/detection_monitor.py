"""Live per-channel inference progress and the scanner-coordinate tile overlay."""
from datetime import datetime
from time import monotonic

import numpy as np
from qtpy.QtCore import QEvent, QPointF, Qt, QTimer
from qtpy.QtGui import QColor, QPainter, QPen
from qtpy.QtWidgets import (QFormLayout, QGroupBox, QLabel, QPlainTextEdit,
                            QProgressBar, QVBoxLayout, QWidget)
from ..core.log import log


class TileOverlay(QWidget):
    def __init__(self, canvas, viewer):
        super().__init__(canvas.native)
        self.canvas = canvas
        self.boxes = []
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        canvas.native.installEventFilter(self)
        viewer.camera.events.connect(self._changed)
        self.setGeometry(canvas.native.rect())

    def _changed(self, event=None):
        self.update()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Resize:
            self.setGeometry(obj.rect())
        return False

    def paintEvent(self, event):
        if not self.boxes:
            return
        transform = self.canvas.view.transform * self.canvas.view.scene.transform
        p = QPainter(self)
        pen = QPen(QColor(88, 88, 88, 165), 1.4, Qt.DashLine)
        p.setPen(pen)
        def line(x, y, u, v):
            a,b = transform.map([[x,y,0,1],[u,v,0,1]])
            p.drawLine(QPointF(*(a[:2]/a[3])), QPointF(*(b[:2]/b[3])))
        for (x,y,w,h), stride in self.boxes:
            for u in np.arange(0,w,stride):
                line(x+u,y,x+u,y+h)
            line(x+w,y,x+w,y+h)
            for v in np.arange(0,h,stride):
                line(x,y+v,x+w,y+v)
            line(x,y+h,x+w,y+h)
        p.end()


def clock_text(seconds):
    minutes, sec = divmod(int(max(0,seconds)),60)
    return f'{minutes:02d}:{sec:02d}'


class DetectionMonitor(QGroupBox):
    def __init__(self):
        super().__init__('识别进度与日志')
        layout = QVBoxLayout(self)
        self.section = QLabel('等待读取脑片')
        self.section.setWordWrap(True)
        layout.addWidget(self.section)
        self.form = QFormLayout()
        layout.addLayout(self.form)
        self.messages = QPlainTextEdit()
        self.messages.setReadOnly(True)
        self.messages.setMaximumBlockCount(2500)
        self.messages.setMinimumHeight(110)
        layout.addWidget(self.messages)
        self.rows = {}
        self.rates = {}
        self.timer = QTimer(self)
        self.timer.setInterval(350)
        self.timer.timeout.connect(self.refresh)

    def note(self, text):
        self.messages.appendPlainText(f'{datetime.now():%H:%M:%S}  {text}')
        log.info('%s', text)

    def end(self, reason=''):
        self.timer.stop()
        for row in self.rows.values():
            if row['begin'] is not None:
                row['seconds'] += monotonic()-row['begin']
                row['begin'] = None
        self.refresh()
        if reason:
            self.note(reason)

    def event_data(self, ev):
        kind = ev['kind']
        if kind == 'section':
            self.end()
            while self.form.rowCount():
                self.form.removeRow(0)
            self.rows.clear()
            self.section.setText(ev['title'])
            self.note(ev['title']+'  '+ev['grid'])
            for c, name in ev['channels'].items():
                bar = QProgressBar()
                bar.setRange(0,ev['total'])
                self.form.addRow(name,bar)
                self.rows[c] = dict(bar=bar, name=name, done=0, total=ev['total'],
                                    begin=None, seconds=0., samples=0)
            self.timer.start()
        elif kind == 'note':
            self.note(ev['text'])
        elif kind == 'end':
            self.end(ev['text'])
        elif kind in ('start','done','skip'):
            row = self.rows[ev['channel']]
            if kind == 'start':
                row['begin'] = monotonic()
                row['pixels'] = ev['pixels']
            else:
                row['seconds'] += ev.get('duration',0.)
                row['samples'] += int(kind=='done')
                if kind == 'done':
                    self.rates[row['name']] = ev['duration']/row['pixels']
                row['done'] += 1
                row['begin'] = None
            self.note(f"{self.section.text()} · {row['name']} · {ev['text']}")
        self.refresh()

    def refresh(self):
        for r in self.rows.values():
            spent = r['seconds'] + (monotonic()-r['begin'] if r['begin'] is not None else 0.)
            remaining = r['total']-r['done']
            eta = ('00:00' if not remaining else clock_text(max(0.,r['seconds']/r['samples']*remaining-(spent-r['seconds']))) if r['samples'] else '估算中')
            if remaining and not r['samples'] and r['begin'] is not None and r['name'] in self.rates:
                eta = clock_text(self.rates[r['name']]*r['pixels']*remaining - (spent-r['seconds']))
            r['bar'].setValue(r['done'])
            r['bar'].setFormat(f"{r['done']}/{r['total']} 块 · 已用 {clock_text(spent)} · 预计剩余 {eta}")
