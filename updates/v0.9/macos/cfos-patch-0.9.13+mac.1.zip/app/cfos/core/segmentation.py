"""Channel model selection and the resident StarDist fluorescence predictor."""
import importlib.util
import sys
import threading
from functools import lru_cache
from pathlib import Path

import numpy as np
from skimage.draw import polygon

from . import accel, cellpose4
from .sdnet import OnnxStarDist

STAR = 'stardist:2D_versatile_fluo'
NAMES = {STAR: 'StarDist（荧光细胞核）', cellpose4.MODEL_KEY: 'Cellpose 4（cpsam_v2）'}
_model_lock = threading.Lock()


def default_model(channel_name):
    return STAR if channel_name.strip().upper() == 'DAPI' else cellpose4.MODEL_KEY


@lru_cache(maxsize=2)
def _star_model(preference):
    directory = Path(__file__).with_name('star_model')
    return OnnxStarDist(directory, directory/'model.onnx', '2D_versatile_fluo')


@lru_cache(maxsize=1)
def _nms():
    if sys.platform not in ('darwin', 'win32'):
        from stardist.lib.stardist2d import c_non_max_suppression_inds
        return c_non_max_suppression_inds
    abi = f'cp{sys.version_info.major}{sys.version_info.minor}'
    root = Path(__file__).with_name('star_native')/abi/('mac' if sys.platform=='darwin' else 'win')
    binary = next(root.glob('stardist2d.*'), None)
    if binary is None:
        raise RuntimeError(f'StarDist 缺少当前 Python 版本的组件（{abi}）。')
    spec = importlib.util.spec_from_file_location('stardist2d',binary)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.c_non_max_suppression_inds


def star_labels(x):
    # Match StarDist2D sparse NMS, including its two-grid-cell border and
    # low-to-high probability drawing order for overlapping polygons.
    with _model_lock:
        model = _star_model(accel.PREF)
        prob, rays, _, _ = model._net(x)
        nms = _nms()
    mask = prob > model.thresholds.prob
    mask[:2] = mask[-2:] = False
    mask[:, :2] = mask[:, -2:] = False
    yy, xx = np.nonzero(mask)
    points = np.column_stack((yy, xx)) * np.array(model.config.grid)
    valid = (points[:,0] < x.shape[0]) & (points[:,1] < x.shape[1])
    order = np.where(valid)[0][np.argsort(prob[yy[valid], xx[valid]])[::-1]]
    labels = np.zeros(x.shape, dtype=np.int32)
    if not len(order):
        return labels
    distances = np.ascontiguousarray(rays[yy[order], xx[order]], dtype=np.float32)
    centers = np.ascontiguousarray(points[order], dtype=np.float32)
    keep = nms(distances, centers, 1, 1, 0, np.float32(model.thresholds.nms))
    distances, centers = distances[keep], centers[keep]
    angles = np.linspace(0, 2*np.pi, model.config.n_rays, endpoint=False)
    coords = (distances[:,None,:]*np.array([np.sin(angles), np.cos(angles)])).astype(np.float32)
    coords += centers[:,:,None]
    for i in np.argsort(prob[yy[order],xx[order]][keep], kind='stable'):
        rr,cc = polygon(*coords[i],shape=x.shape)
        labels[rr,cc] = i+1
    return labels


def predict(image, params, cancel=None):
    if cancel and cancel():
        raise InterruptedError
    if params.model == STAR:
        labels = star_labels(image)
        if cancel and cancel():
            raise InterruptedError
        return labels, accel._status['device'] or 'ONNX Runtime'
    labels = cellpose4.predict_labels(image, cellprob_threshold=params.cellprob_threshold, cancel=cancel)
    return labels, cellpose4.backend_text()
