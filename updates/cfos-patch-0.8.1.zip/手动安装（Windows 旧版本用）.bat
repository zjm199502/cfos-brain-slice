@echo off
chcp 65001 >nul
setlocal
set "SRC=%~dp0app"
set "DST=%LOCALAPPDATA%\cFos脑片分析\app"
if not exist "%SRC%\cfos\__init__.py" (
  echo 请先把补丁 zip 解压（右键 → 全部解压），再双击解压出来的这个文件。
  pause
  exit /b 1
)
if not exist "%DST%\main.py" (
  echo 没有在默认位置找到已安装的 FosMap 脑片活动图谱（原名 cFos 脑片分析）：
  echo   %DST%
  echo 请把补丁里 app 文件夹中的全部内容，复制到你的安装目录下的 app 文件夹里（覆盖同名文件）。
  pause
  exit /b 1
)
echo 将安装补丁 v0.8.1 到：%DST%
echo 请先关闭 FosMap 脑片活动图谱（原名 cFos 脑片分析），然后按任意键开始…
pause >nul
xcopy "%SRC%" "%DST%" /E /Y /I /Q >nul
if errorlevel 1 (
  echo 复制失败。请确认软件已经关闭后重试。
  pause
  exit /b 1
)
echo.
echo 补丁已安装，可以打开软件了。以后的更新可以在软件里“帮助 → 检查更新”自动完成。
pause
