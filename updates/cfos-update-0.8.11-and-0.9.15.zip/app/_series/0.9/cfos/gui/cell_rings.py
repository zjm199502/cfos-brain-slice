"""Screen-width dashed cell markers for the editable napari points layers."""
import numpy as np
from qtpy.QtCore import QEvent, QSettings, Qt
from qtpy.QtGui import QColor, QImage, QPainter
from qtpy.QtWidgets import QWidget

from ..core.manual import ADD_RADIUS_UM
from ..core.cell_markers import diameters, draw_rings


class CellRings(QWidget):
    """Paint visible circles in the canvas without intercepting selection or edits."""
    def __init__(self, canvas, viewer):
        super().__init__(canvas.native)
        self.canvas = canvas
        self.layers = {}
        self.settings = QSettings("cfos", "cfos脑片分析")
        self.width_pt = self.settings.value("cellRingWidthPt", 0.75, type=float)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        canvas.native.installEventFilter(self)
        self.setGeometry(canvas.native.rect())
        viewer.camera.events.connect(self._changed)
        viewer.layers.events.removed.connect(self._removed)
        viewer.layers.events.reordered.connect(self._changed)
        self.viewer = viewer

    def attach(self, layer, color):
        self.layers[layer] = QColor(color)
        for event in (layer.events.data, layer.events.size, layer.events.visible, layer.events.opacity):
            event.connect(self._changed)
        self.update()

    def set_color(self, layer, color):
        self.layers[layer] = QColor(color)
        self.update()

    def set_width(self, width):
        self.width_pt = width
        self.settings.setValue("cellRingWidthPt", width)
        self.update()

    def _removed(self, event):
        if self.layers.pop(event.value, None) is not None:
            self.update()

    def _changed(self, event=None):
        self.update()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Resize:
            self.setGeometry(obj.rect())
        return False

    def paintEvent(self, event):
        if not self.layers:
            return
        # The same scanner-to-logical-canvas transform used for the tile grid.
        transform = self.canvas.view.transform * self.canvas.view.scene.transform
        basis = transform.map([[0, 0, 0, 1], [1, 0, 0, 1], [0, 1, 0, 1]])
        origin, xx, yy = basis[:, :2] / basis[:, 3, None]
        mat = np.stack((yy - origin, xx - origin))
        scale = float(np.linalg.norm(mat[1]))
        pen_width = self.width_pt * self.logicalDpiX() / 72.
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.Antialiasing)
            for layer in self.viewer.layers:
                if layer not in self.layers or not layer.visible or not layer.opacity or not len(layer.data):
                    continue
                xy = np.asarray(layer.data)[:, -2:] @ mat + origin
                rad = np.asarray(layer.size) * (scale / 2)
                x, y = xy.T
                pad = rad + pen_width
                visible = (x >= -pad) & (x <= self.width() + pad) & (y >= -pad) & (y <= self.height() + pad)
                painter.setOpacity(layer.opacity)
                # Sub-pixel rings cannot be resolved at whole-slide zoom. Draw
                # their occupied pixels together instead of issuing one Qt call per cell.
                small = visible & (rad < 0.5)
                if np.any(small):
                    u, v = np.rint(xy[small]).astype(int).T
                    inside = (u >= 0) & (u < self.width()) & (v >= 0) & (v < self.height())
                    rgba = np.zeros((self.height(), self.width(), 4), dtype=np.uint8)
                    rgba[v[inside], u[inside]] = self.layers[layer].getRgb()
                    dots = QImage(rgba.data, self.width(), self.height(), rgba.strides[0], QImage.Format_RGBA8888)
                    painter.drawImage(0, 0, dots)
                rings = visible & ~small
                draw_rings(painter, xy[rings], rad[rings], self.layers[layer], pen_width)
        finally:
            painter.end()


def add_cell_layer(window, frame, channel, name, editable):
    """Sizing follows mask area. Manual additions use their measurement radius."""
    px = window.slide.pixel_size_um
    default_size = 2 * ADD_RADIUS_UM / px
    position = frame[["y", "x"]].to_numpy(float) if frame is not None else np.empty((0, 2))
    size = diameters(frame, px) if frame is not None and len(frame) else default_size
    ids = frame.index.to_numpy() if frame is not None else np.empty(0, int)
    layer = window.viewer.add_points(position, name=name, size=size, face_color="transparent",
                                     border_color="transparent", features={"cid": ids},
                                     metadata={"cell_channel": channel})
    layer.current_size = default_size
    layer.feature_defaults = {"cid": -1}
    layer.editable = editable
    window.cell_rings.attach(layer, window.ch_point_color(channel))
    return layer
