"""Native STAM coronal registration results; geometry is millimetres in the STAM image frame."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import hashlib
import os
from pathlib import Path
import tempfile

import numpy as np
from scipy import ndimage as ndi

from . import registration as R
from . import stam

METHOD = "STAM_giRAff"


@dataclass
class NativeRegistration:
    plane_native_mm: list = field(default_factory=list)
    orientation: str = "r0"
    bbox0: list = field(default_factory=list)
    shape_hw: list = field(default_factory=list)
    downsample: float = 1.
    warp_file: str = ""
    nonlinear: bool = False
    metrics: dict = field(default_factory=dict)
    initialization: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

    @property
    def done(self):
        return len(self.plane_native_mm) == 9

    @property
    def ap_mm(self):
        o, u, v = np.reshape(self.plane_native_mm, (3, 3))
        return float(5.230 - (o + (u+v)/2)[2])

    @property
    def status(self):
        if not self.done:
            return "尚未执行 giRAff 配准"
        return "STAM · giRAff 仿射" + (" + 非线性贴合" if self.nonlinear else "")

    def to_dict(self):
        return asdict(self)


def _sample(plane_mm, shape, volume, spacing_mm, order, warp=None):
    o, u, v = np.asarray(plane_mm, dtype=np.float64).reshape(3, 3)
    height, width = shape
    # Tile rows to keep peak memory bounded on large slide thumbnails.
    result = np.empty(shape, dtype=volume.dtype)
    for top in range(0, height, 128):
        bottom = min(height, top+128)
        y, x = np.mgrid[top:bottom, :width].astype(np.float32)
        if warp is not None:
            x += warp[0][top:bottom]
            y += warp[1][top:bottom]
        x = (x + .5) / width
        y = (y + .5) / height
        coords = [(o[i] + x*u[i] + y*v[i])/spacing_mm for i in (2, 1, 0)]
        result[top:bottom] = ndi.map_coordinates(volume, coords, order=order, mode="constant")
    return result


def _save_warp(results_dir, warp):
    folder = Path(results_dir) / "stam_giraff"
    folder.mkdir(exist_ok=True, parents=True)
    data = np.ascontiguousarray(warp, dtype=np.float32)
    # Immutable warp names keep existing projects and backups valid if a job is interrupted.
    digest = hashlib.sha256()
    digest.update(str(data.shape).encode("ascii"))
    digest.update(data.data)
    name = digest.hexdigest() + ".npy"
    if not (folder / name).exists():
        with tempfile.NamedTemporaryFile(dir=folder, suffix=".tmp", delete=False) as f:
            tmp = Path(f.name)
        try:
            with tmp.open("wb") as f:
                np.save(f, data, allow_pickle=False)
            os.replace(tmp, folder / name)
        finally:
            tmp.unlink(missing_ok=True)
    return name


def _load_warp(results_dir, result):
    warp = None
    if result.nonlinear:
        name = result.warp_file
        if not name or Path(name).name != name:
            raise ValueError("缺少有效的 STAM 位移场文件名")
        path = Path(results_dir) / "stam_giraff" / name
        if not path.is_file():
            raise FileNotFoundError("项目缺少 STAM 位移场，请取消勾选使用非线性结果以查看仿射结果，或重新配准")
        warp = np.load(path, allow_pickle=False, mmap_mode="r")
        if tuple(warp.shape) != (2, *result.shape_hw):
            raise ValueError("STAM 位移场与脑片缩略图尺寸不一致，请重新配准")
    return warp


def label_map(results_dir, result):
    warp = _load_warp(results_dir, result)
    label = _sample(result.plane_native_mm, result.shape_hw, stam.volumes()[1], .040, 0, warp)
    return R.orient(label, result.orientation)


def fit_section(slide, section, nuc, results_dir, nonlinear, progress=None, cancelled=None):
    from . import stam_giraff
    from . import stam_refinement

    image, mask, ds = R.section_thumbnail(slide, section, nuc)
    pixel_um = float(ds * slide.pixel_size_um)
    geometry, image, mask = stam_giraff.fit(image, mask, pixel_um, progress=progress, cancelled=cancelled)
    plane = np.asarray(geometry["plane_native_mm"], dtype=float)
    if plane.size != 9 or not np.isfinite(plane).all() or geometry["orientation"] not in ("r0", "r180"):
        raise ValueError("STAM 定位未返回有效的冠状平面")
    result = NativeRegistration(plane_native_mm=plane.reshape(9).tolist(), orientation=geometry["orientation"],
                                shape_hw=list(image.shape), downsample=float(ds), bbox0=list(section.bbox0),
                                initialization={k:v for k,v in geometry.items() if k not in ("plane_native_mm","orientation")})
    if nonlinear:
        if cancelled and cancelled():
            raise InterruptedError
        if progress:
            progress(0, 1, "正在拟合 STAM 组织外轮廓…")
        reference = _sample(plane, image.shape, stam.volumes()[0], .032, 1)
        support = stam_refinement.tissue_mask(reference, pixel_um=pixel_um)
        warp, metrics = stam_refinement.refine(image, mask, reference, support, pixel_um=pixel_um)
        result.metrics = metrics
        if cancelled and cancelled():
            raise InterruptedError
        if warp is not None:
            if np.shape(warp) != (2, *image.shape) or not np.isfinite(warp).all():
                raise ValueError("STAM 非线性位移场无效")
            result.warp_file = _save_warp(results_dir, warp)
            result.nonlinear = True
        else:
            result.warnings.append(str(metrics.get("reason") or "非线性贴合未改善配准，已保留仿射结果"))
    else:
        reference = _sample(plane, image.shape, stam.volumes()[0], .032, 1)
        support = stam_refinement.tissue_mask(reference, pixel_um=pixel_um)
        if np.any(mask) and np.any(support):
            result.metrics = {"before": stam_refinement.outline_metrics(mask, support, pixel_um)}
    return result

def outline_map(results_dir, result, pixel_um):
    from . import stam_refinement

    ref = _sample(result.plane_native_mm, result.shape_hw, stam.volumes()[0], .032, 1)
    tissue = stam_refinement.tissue_mask(ref, pixel_um=pixel_um)
    tissue = stam_refinement.resample(tissue, _load_warp(results_dir, result), 0)
    return R.orient(tissue, result.orientation)
