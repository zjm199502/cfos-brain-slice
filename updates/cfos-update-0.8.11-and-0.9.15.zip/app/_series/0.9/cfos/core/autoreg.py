"""Locate and refine sections directly in STAM space."""
from . import stam_native
from .registration import Registration


def run(project, targets, nuc, nonlinear=True, refine=True, unify=False, progress=None, cancelled=None, only=None, slides=None):
    say = progress or (lambda done, total, msg: None)
    out = {}
    for image in targets:
        sections = [s for s in image.sections if s.enabled and (only is None or s.name in only.get(image.key, ()))]
        if not sections:
            continue
        slide = (slides or {}).get(image.source_id)
        own = slide is None
        if own:
            slide = image.open_slide(z_mode=project.z_mode)
        try:
            results = {}
            for section in sections:
                if cancelled and cancelled():
                    raise InterruptedError
                say(0, 1, f"正在用 giRAff 定位 {image.key} {section.name}…")
                result = stam_native.fit_section(
                    slide, section, nuc, project.results_dir, nonlinear, say, cancelled)
                results[section.name] = Registration.from_dict(result.to_dict())
            out[image.source_id] = results
        finally:
            if own:
                slide.close()
    return out

