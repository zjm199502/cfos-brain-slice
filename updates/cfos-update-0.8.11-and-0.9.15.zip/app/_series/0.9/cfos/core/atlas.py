"""Native STAM volumes and section geometry."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import pandas as pd
from scipy import ndimage as ndi

from . import stam

# Plane editing uses axes right/anterior/superior in units of 25 µm.
# Serialized planes and atlas coordinates use native STAM xyz millimetres.
def native_mm(edit_coords):
    return np.asarray(edit_coords)[..., (0, 2, 1)] * np.array([.025, -.025, -.025])


def edit_coords(native):
    return np.asarray(native)[..., (0, 2, 1)] * np.array([40., -40., -40.])



@dataclass
class Atlas:
    annotation: np.ndarray   # uint16，0 为背景，其余为 structures 表中的 index
    reference: np.ndarray    # uint8，平均模板
    hemispheres: np.ndarray  # uint8，1/2
    structures: pd.DataFrame

    @property
    def n_regions(self):
        return len(self.structures)


@lru_cache(maxsize=1)
def load_atlas() -> Atlas:
    from .region_sets import ZH
    reference, labels = stam.volumes()
    structures = pd.read_csv(stam.DATA / "structures.csv", keep_default_na=False)
    structures["name_zh"] = structures["acronym"].map(ZH).fillna("")
    sides = np.where(labels != 0, 2, 0).astype(np.uint8)
    return Atlas(labels, reference, sides, structures)


@dataclass
class Plane:
    o: np.ndarray
    u: np.ndarray
    v: np.ndarray

    def to_list(self):
        return [float(x) for x in np.concatenate([self.o, self.u, self.v])]

    @staticmethod
    def from_list(a):
        a = np.asarray(a, float)
        return Plane(a[0:3], a[3:6], a[6:9])

    # ---- 便于手动调整的参数化 ----
    def center(self):
        return self.o + 0.5 * self.u + 0.5 * self.v

    def ap_mm(self):
        return float(5.230 - native_mm(self.center())[2])


def sample_plane(plane: Plane, width: int, height: int, which=("annotation",), order_ref=1,
                 warp: tuple[np.ndarray, np.ndarray] | None = None) -> dict[str, np.ndarray]:
    """按平面切出 height×width 的图谱图像。warp=(dx, dy) 为每个像素的额外位移（像素单位，非线性修正）。"""
    at = load_atlas()
    t, s = np.mgrid[0:height, 0:width].astype(np.float32)
    if warp is not None:
        s = s + warp[0]
        t = t + warp[1]
    s = (s + 0.5) / width
    t = (t + 0.5) / height
    p = plane.o[None, None, :] + s[..., None] * plane.u[None, None, :] + t[..., None] * plane.v[None, None, :]
    coords = np.moveaxis(native_mm(p)[..., ::-1], -1, 0)
    out = {}
    for w in which:
        spacing = .032 if w == "reference" else .040
        out[w] = ndi.map_coordinates(getattr(at, w), coords / spacing,
                                      order=order_ref if w == "reference" else 0, mode="constant")
    return out


def region_boundaries(label: np.ndarray) -> np.ndarray:
    """脑区边界掩膜。"""
    b = np.zeros(label.shape, bool)
    b[:, 1:] |= label[:, 1:] != label[:, :-1]
    b[1:, :] |= label[1:, :] != label[:-1, :]
    return b


def region_colors(label: np.ndarray) -> np.ndarray:
    at = load_atlas()
    lut = np.zeros((at.n_regions + 1, 3), np.uint8)
    lut[1:] = at.structures[["r", "g", "b"]].to_numpy()
    return lut[label]
