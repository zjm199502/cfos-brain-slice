"""STAM section registration, manual adjustments and label sampling."""
from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field, asdict

import numpy as np
from scipy import ndimage as ndi

from .atlas import Plane, sample_plane, load_atlas, native_mm, edit_coords
from .resources import resources_dir
from .sections import Section, tissue_mask
from .slide_io import Slide

THUMB_UM = 8.0  # 配准使用的分辨率（µm/像素）


@dataclass
class Registration:
    orientation: str = "r0"                # 'r0' 或 'r180'：缩略图相对原图的旋转
    mirror: bool = False                   # 左右翻转（只影响左右半脑的判定）
    plane: list = field(default_factory=list)   # giRAff 原生平面的编辑坐标（联合校正后为校正后的值）
    plane_raw: list = field(default_factory=list)  # 联合校正前 giRAff 的原始结果（用于撤销）
    ap_shift: float = 0.0                  # 前后平移（体素，25 µm）
    ap_auto: float = 0.0                   # 自动校正的前后平移（体素，v0.8.5）；与 ap_shift 相加，滑块只显示手动部分
    tilt_dv: float = 0.0                   # 背腹方向倾斜（度）
    tilt_ml: float = 0.0                   # 左右方向倾斜（度）
    scale_x: float = 1.0
    scale_y: float = 1.0
    rotation: float = 0.0                  # 平面内旋转（度）
    shift_x: float = 0.0                   # 平面内平移（图像宽度的比例）
    shift_y: float = 0.0
    control_points: list = field(default_factory=list)  # [[src_s, src_t, dst_s, dst_t], ...] 归一化坐标
    nonlinear: bool = False                # 是否使用 elastix 非线性贴合
    nl_method: str = ""                    # 非线性贴合实际用的方法（"轮廓 + DAPI 纹理" / "只用轮廓"；v0.7 前为空）
    warnings: list = field(default_factory=list)  # 自动配准后需要人工重点检查的原因（v0.8.5）；手动调整后清空
    status: str = "未配准"

    warp_file: str = ""
    bbox0: list = field(default_factory=list)
    shape_hw: list = field(default_factory=list)
    downsample: float = 1.
    initialization: dict = field(default_factory=dict)
    metrics: dict = field(default_factory=dict)

    def to_dict(self):
        data = asdict(self)
        plane = data.pop("plane")
        data["plane_native_mm"] = native_mm(np.reshape(plane, (3,3))).ravel().tolist() if plane else []
        return data

    @classmethod
    def from_dict(cls, data):
        if not data or not data.get("plane_native_mm"):
            return cls()
        values = {k:v for k,v in data.items() if k in cls.__dataclass_fields__}
        values["plane"] = edit_coords(np.reshape(data["plane_native_mm"], (3,3))).ravel().tolist()
        values.setdefault("status", "STAM · giRAff")
        if data.get("nonlinear"):
            values.setdefault("nl_method", "轮廓 + DAPI 纹理")
        return cls(**values)

    @property
    def done(self):
        return bool(self.plane)


# ------------------------------------------------------------------ 缩略图和方向
def section_thumbnail(slide: Slide, section: Section, nucleus_ch: int | None):
    """返回 (缩略图 uint8, 组织掩膜, 缩略图像素对应的第 0 层像素数)。"""
    lv = slide.level_for_pixel_size(THUMB_UM)
    ds = slide.downsample(lv)
    a = slide.read(lv, section.bbox0).astype(np.float32)
    chans = [nucleus_ch] if nucleus_ch is not None else list(range(a.shape[0]))
    ims = []
    for c in chans:
        x = a[c]
        hi = np.percentile(x, 99.5)
        ims.append(np.clip(x / max(hi, 1e-6), 0, 1))
    img = (np.max(ims, axis=0) * 255).astype(np.uint8)
    mask = tissue_mask(a, slide.pixel_size_um * ds)
    return img, mask, ds


def orient(img: np.ndarray, orientation: str) -> np.ndarray:
    if orientation == "r180":
        return np.ascontiguousarray(img[::-1, ::-1])
    return img


def dice(a: np.ndarray, b: np.ndarray) -> float:
    s = a.sum() + b.sum()
    return 2.0 * np.logical_and(a, b).sum() / s if s else 0.0


def _rot(axis, deg):
    axis = axis / (np.linalg.norm(axis) + 1e-12)
    a = np.deg2rad(deg)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(a) * K + (1 - np.cos(a)) * K @ K


def adjusted_plane(reg: Registration) -> Plane:
    pl = Plane.from_list(reg.plane)
    o, u, v = pl.o.copy(), pl.u.copy(), pl.v.copy()
    c = o + 0.5 * u + 0.5 * v
    n = np.cross(u, v)
    n /= np.linalg.norm(n) + 1e-12
    # 前后平移：沿平面法向（让 y 增大的方向为“向前”）
    if n[1] < 0:
        n = -n
    c = c + n * (reg.ap_shift + reg.ap_auto)
    # 倾斜：绕 u 轴（背腹倾斜）、绕 v 轴（左右倾斜）
    R = _rot(v, reg.tilt_ml) @ _rot(u, reg.tilt_dv)
    u, v = R @ u, R @ v
    # 平面内：缩放、旋转、平移（围绕中心）
    th = np.deg2rad(reg.rotation)
    A = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]]) @ np.diag([1 / reg.scale_x, 1 / reg.scale_y])
    u2 = A[0, 0] * u + A[1, 0] * v
    v2 = A[0, 1] * u + A[1, 1] * v
    c = c - reg.shift_x * u - reg.shift_y * v
    o2 = c - 0.5 * u2 - 0.5 * v2
    return Plane(o2, u2, v2)


def tps_warp(points: list, W: int, H: int):
    """修正点 → 每个像素的位移（像素单位）。points: [[src_s, src_t, dst_s, dst_t(, radius)]]，归一化坐标
    （radius 以图宽为单位，可省略）。含义：图谱中原本在 src 处的内容被拖到了 dst，因此在 dst 处采样时要取 src 的图谱内容。
    不带 radius 的点：薄板样条（全局平滑，四周固定）。带 radius 的点：只影响 dst 周围 radius 以内，
    位移按 (1 - (d/r)^2)^2 平滑衰减到 0（边界弹性跟随，远处完全不动）。"""
    if not points:
        return None
    P = [list(map(float, q)) for q in points]
    glob = [q for q in P if len(q) < 5 or q[4] <= 0]
    local = [q for q in P if len(q) >= 5 and q[4] > 0]
    step = 4
    gy, gx = np.mgrid[0:H:step, 0:W:step]
    g = np.zeros(gy.shape + (2,), np.float64)
    if glob:
        from scipy.interpolate import RBFInterpolator
        Q = np.asarray(glob, float)
        dst = Q[:, 2:4] * [W, H]
        disp = (Q[:, 0:2] - Q[:, 2:4]) * [W, H]
        # 四周固定点，让修正只影响局部
        border = []
        for f in np.linspace(0, 1, 6):
            border += [[f * W, 0], [f * W, H], [0, f * H], [W, f * H]]
        border = np.unique(np.round(np.array(border), 3), axis=0)
        dmin = np.min(np.linalg.norm(border[:, None, :] - dst[None, :, :], axis=2), axis=1)
        border = border[dmin > 1.0]
        X = np.vstack([dst, border])
        Y = np.vstack([disp, np.zeros_like(border)])
        rbf = RBFInterpolator(X, Y, kernel="thin_plate_spline", smoothing=1e-6)
        g += rbf(np.stack([gx.ravel(), gy.ravel()], 1)).reshape(gy.shape + (2,))
    for q in local:
        sx, sy, dx, dy = q[0] * W, q[1] * H, q[2] * W, q[3] * H
        r = max(q[4] * W, 2.0)
        d2 = ((gx - dx) ** 2 + (gy - dy) ** 2) / (r * r)
        wgt = np.clip(1.0 - d2, 0.0, None) ** 2
        g[..., 0] += wgt * (sx - dx)
        g[..., 1] += wgt * (sy - dy)
    full = [ndi.zoom(g[..., k], (H / g.shape[0], W / g.shape[1]), order=1)[:H, :W] for k in range(2)]
    return full[0], full[1]


_TPS_CACHE: dict = {}


def tps_warp_cached(points: list, W: int, H: int):
    """tps_warp 的结果按修正点缓存一份：拖滑块时修正点不变，不用每次重算（v0.8.5）。返回的数组不要原地修改。"""
    if not points:
        return None
    key = (tuple(tuple(float(v) for v in q) for q in points), W, H)
    if _TPS_CACHE.get("key") != key:
        _TPS_CACHE["key"], _TPS_CACHE["val"] = key, tps_warp(points, W, H)
    return _TPS_CACHE["val"]


def warp_path(results_dir, image_key, section_name, reg):
    from pathlib import Path
    name = reg.warp_file
    if name and (len(name) != 68 or not name.endswith(".npy") or any(c not in "0123456789abcdef" for c in name[:-4])):
        raise ValueError("STAM 位移场文件名无效。")
    path = Path(results_dir) / "stam_giraff" / (name or "no-warp")
    if reg.nonlinear and not path.is_file():
        raise FileNotFoundError("项目缺少 STAM 位移场，请重新配准这张脑片。")
    return path


NL_GRIDS = (40.0, 60.0)   # B 样条控制点间距（缩略图像素），依次尝试：先 40，出现折叠再放宽到 60。
NL_GRID = NL_GRIDS[0]     # v0.8.5 前是 20：示例图的第 2 张脑片在 20 下发生折叠、整个纹理贴合被放弃；
                          # 40 在两张脑片上都不折叠，独立检验（NeuN 灰质/白质亮度比）也不比 20 差
NL_TEXTURE_W = 0.5        # DAPI 纹理在贴合中的权重（其余为组织轮廓）

_ITK_LOCK = threading.Lock()
_ITK = {}


def _itk():
    """加载 elastix。第一次要约 10 秒（ITK 按需加载大量模块），所以进入配准页面时会在后台线程里先加载
    （preload_elastix）；这里加锁，保证后台和正式使用同时发生时只加载一次。"""
    with _ITK_LOCK:
        if "itk" not in _ITK:
            import itk
            itk.ElastixRegistrationMethod[itk.Image[itk.F, 2], itk.Image[itk.F, 2]]
            try:    # 只用允许的核数（软件最多用一半的核）
                from .cpu import budget
                itk.MultiThreaderBase.SetGlobalDefaultNumberOfThreads(budget())
            except Exception:  # noqa: BLE001
                pass
            _ITK["itk"] = itk
    return _ITK["itk"]


def preload_elastix():
    """在后台线程里提前加载 elastix；失败不报错（真正用到时再报）。"""
    def run():
        try:
            _itk()
        except Exception:  # noqa: BLE001
            pass
    if "itk" not in _ITK:
        threading.Thread(target=run, name="preload-elastix", daemon=True).start()


def _elastix(fixed, moving, fixed2=None, moving2=None, grid=NL_GRID, w2=NL_TEXTURE_W, bspline=True, iters=300):
    """bspline=False：只做仿射（用于前后位置搜索，快）。"""
    itk = _itk()
    m = itk.ElastixRegistrationMethod[itk.Image[itk.F, 2], itk.Image[itk.F, 2]].New()
    m.SetFixedImage(itk.image_view_from_array(np.ascontiguousarray(fixed)))
    m.SetMovingImage(itk.image_view_from_array(np.ascontiguousarray(moving)))
    po = itk.ParameterObject.New()
    aff = po.GetDefaultParameterMap("affine", 3)
    aff["MaximumNumberOfIterations"] = [str(iters)]
    bs = po.GetDefaultParameterMap("bspline", 3, 40.0)
    bs["MaximumNumberOfIterations"] = [str(iters)]
    bs["FinalGridSpacingInPhysicalUnits"] = [str(grid)]
    if fixed2 is not None:
        m.AddFixedImage(itk.image_view_from_array(np.ascontiguousarray(fixed2)))
        m.AddMovingImage(itk.image_view_from_array(np.ascontiguousarray(moving2)))
        for pm, w in ((aff, 0.0), (bs, w2)):    # 仿射只用轮廓；B 样条同时用轮廓和纹理
            pm["Registration"] = ["MultiMetricMultiResolutionRegistration"]
            pm["Metric"] = ["AdvancedMattesMutualInformation", "AdvancedMattesMutualInformation"]
            pm["Metric0Weight"] = [str(1.0 - w if w > 0 else 1.0)]
            pm["Metric1Weight"] = [str(w)]
            for k, v in (("FixedImagePyramid", "FixedSmoothingImagePyramid"),
                         ("MovingImagePyramid", "MovingSmoothingImagePyramid"),
                         ("Interpolator", "BSplineInterpolator"), ("ImageSampler", "RandomCoordinate")):
                pm[k] = [v, v]
    po.AddParameterMap(aff)
    if bspline:
        po.AddParameterMap(bs)
    m.SetParameterObject(po); m.SetLogToConsole(False)
    m.UpdateLargestPossibleRegion()
    field_ = itk.transformix_deformation_field(itk.image_view_from_array(np.ascontiguousarray(moving)),
                                               m.GetTransformParameterObject())
    f = itk.array_from_image(field_)  # (H, W, 2)，单位：像素，(x, y)
    return f[..., 0].astype(np.float32), f[..., 1].astype(np.float32)


def min_jacobian(w) -> float:
    """位移场的最小雅可比行列式；≤ 0 表示局部发生了折叠（不合理的变形）。"""
    gx = np.gradient(w[0]); gy = np.gradient(w[1])
    return float(((1 + gx[1]) * (1 + gy[0]) - gx[0] * gy[1]).min())


TEXTURE, CONTOUR = "轮廓 + DAPI 纹理", "只用轮廓"


def similarity(ref: np.ndarray, img: np.ndarray, mask: np.ndarray) -> float:
    """图谱平均模板与 DAPI 缩略图在组织范围内的互信息（越大越像）。"""
    a = ndi.gaussian_filter(ref.astype(np.float32), 2)
    b = ndi.gaussian_filter(img.astype(np.float32), 2)
    m = mask.astype(bool)
    if m.sum() < 100:
        return 0.0
    h = np.histogram2d(a[m], b[m], bins=48)[0]
    p = h / max(h.sum(), 1.0)
    q = p.sum(1, keepdims=True) * p.sum(0, keepdims=True)
    nz = p > 0
    return float((p[nz] * np.log(p[nz] / q[nz])).sum())


def registered_samples(reg, W, H, warp, x, y, which=("annotation", "hemispheres")):
    """Sample the original atlas at arbitrary oriented section corner coordinates."""
    from .edge_drag import is_fine, transport
    x, y = np.broadcast_arrays(np.asarray(x, dtype=float), np.asarray(y, dtype=float))
    for point in reversed(reg.control_points):
        if is_fine(point):
            x, y = transport(x, y, point, W, H, inverse=True)
    legacy = [p for p in reg.control_points if not is_fine(p)]
    manual = tps_warp_cached(legacy, W, H)
    for field in (manual, warp if reg.nonlinear else None):
        if field is not None:
            coords = [y - .5, x - .5]
            x = x + ndi.map_coordinates(field[0], coords, order=1, mode="nearest")
            y = y + ndi.map_coordinates(field[1], coords, order=1, mode="nearest")
    plane = adjusted_plane(reg)
    s, t = x / W, y / H
    xyz = [plane.o[k] + s*plane.u[k] + t*plane.v[k] for k in range(3)]
    coords = np.stack((-xyz[1], -xyz[2], xyz[0])) * .025
    atlas = load_atlas()
    result = {k: ndi.map_coordinates(getattr(atlas, k), coords/(.032 if k=="reference" else .040),
                                     order=1 if k=="reference" else 0, mode="constant") for k in which}
    if "hemispheres" in result and reg.mirror:
        h = result["hemispheres"]
        result["hemispheres"] = np.where(h == 1, 2, np.where(h == 2, 1, h)).astype(h.dtype)
    return result


def sample_grid(reg, W, H, warp, xs, ys, which):
    """Bound temporary coordinate memory independently of export and preview size."""
    atlas = load_atlas()
    out = {k: np.empty((len(ys), len(xs)), getattr(atlas, k).dtype) for k in which}
    rows = max(1, 192000 // max(1, len(xs)))
    for start in range(0, len(ys), rows):
        sl = slice(start, start + rows)
        values = registered_samples(reg, W, H, warp, xs[None, :], ys[sl, None], which)
        for k in which:
            out[k][sl] = values[k]
    return out


def label_maps(reg: Registration, W: int, H: int, warp=None):
    """在“方向已校正”的缩略图坐标下，生成脑区标签图和半脑图。"""
    if reg.nonlinear and (warp is None or np.shape(warp) != (2, H, W)):
        raise ValueError("STAM 位移场尺寸与脑片不符，请重新配准。")
    from .edge_drag import is_fine
    if any(is_fine(p) for p in reg.control_points):
        r = sample_grid(reg, W, H, warp, np.arange(W) + .5, np.arange(H) + .5,
                        ("annotation", "hemispheres"))
        return r["annotation"], r["hemispheres"]
    pl = adjusted_plane(reg)
    total = None
    t = tps_warp_cached(reg.control_points, W, H)
    if t is not None:
        total = (t[0], t[1])
    if warp is not None and reg.nonlinear:
        if total is None:
            total = (warp[0], warp[1])
        else:
            gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
            px, py = gx + total[0], gy + total[1]
            ex = ndi.map_coordinates(warp[0], [py, px], order=1, mode="nearest")
            ey = ndi.map_coordinates(warp[1], [py, px], order=1, mode="nearest")
            total = (total[0] + ex, total[1] + ey)
    r = sample_plane(pl, W, H, ("annotation", "hemispheres"), warp=total)
    hemi = r["hemispheres"]
    if reg.mirror:
        hemi = np.where(hemi == 1, 2, np.where(hemi == 2, 1, hemi)).astype(hemi.dtype)
    return r["annotation"], hemi


def assign_cells(x0: np.ndarray, y0: np.ndarray, section: Section, reg: Registration, ds: float,
                 shape_hw, warp=None):
    """细胞坐标（第 0 层像素）→ (脑区 index, 半脑 1/2)。"""
    H, W = shape_hw
    lab, hemi = label_maps(reg, W, H, warp)
    return cell_labels(x0, y0, section, reg, ds, lab, hemi, warp)


def cell_labels(x0, y0, section, reg, ds, lab, hemi, warp=None, excluded=None):
    from .edge_drag import is_fine, transport
    H, W = lab.shape
    bx, by = section.bbox0[0], section.bbox0[1]
    px = (np.asarray(x0) - bx) / ds
    py = (np.asarray(y0) - by) / ds
    if reg.orientation == "r180":
        px, py = W - 1 - px, H - 1 - py
    ix = np.clip(np.round(px).astype(int), 0, W - 1)
    iy = np.clip(np.round(py).astype(int), 0, H - 1)
    regions, sides = lab[iy, ix], hemi[iy, ix]
    edits = [point for point in reg.control_points if is_fine(point)]
    if edits:
        # Legacy cell indexing used rounded thumbnail pixels. Only recompute cells
        # within new stroke supports or whose old pixel centre was affected.
        x, y = (np.asarray(x0)-bx)/ds, (np.asarray(y0)-by)/ds
        if reg.orientation == "r180":
            x, y = W-x, H-y
        moved = np.zeros(x.shape, bool)
        for p in edits:
            for cx, cy in ((x,y), (ix+.5,iy+.5)):
                sx, sy = transport(cx, cy, p, W, H, inverse=True)
                moved |= (sx != cx) | (sy != cy)
        if moved.any():
            values = registered_samples(reg,W,H,warp,x[moved],y[moved])
            regions[moved], sides[moved] = values["annotation"], values["hemispheres"]
    if excluded is not None:
        regions[excluded[iy, ix]] = 0
    return regions, sides


HEMI_NAMES = {0: "", 1: "左", 2: "右"}


def region_table():
    return load_atlas().structures


def refit_outline(reg, image, mask, pixel_um, results_dir):
    from . import stam_native, stam_refinement
    h, w = image.shape
    plane = adjusted_plane(reg)
    ref = sample_plane(plane, w, h, ("reference",))["reference"]
    support = stam_refinement.tissue_mask(ref, pixel_um)
    field, reg.metrics = stam_refinement.refine(orient(image, reg.orientation), orient(mask, reg.orientation),
                                                ref, support, pixel_um)
    reg.nonlinear = field is not None
    reg.warp_file = stam_native._save_warp(results_dir, field) if reg.nonlinear else ""
    reg.nl_method = "轮廓 + DAPI 纹理" if reg.nonlinear else ""
    reg.warnings = [] if reg.nonlinear else [reg.metrics["reason"]]
    reg.shape_hw = [h, w]
