#!/bin/bash
# FosMap 脑片活动图谱（原名 cFos 脑片分析）补丁 v0.8.2：手动安装到已安装的程序里（v0.7 等没有自动更新功能的旧版本用）
D="$(cd "$(dirname "$0")" && pwd)"
for A in "/Applications/FosMap脑片活动图谱.app" "$HOME/Applications/FosMap脑片活动图谱.app"          "/Applications/cFos脑片分析.app" "$HOME/Applications/cFos脑片分析.app"; do
  [ -d "$A" ] && break
done
T="$A/Contents/Resources/app"
if [ ! -f "$T/main.py" ]; then
  echo "没有找到已安装的 FosMap脑片活动图谱.app 或 cFos脑片分析.app（应在“应用程序”文件夹里）。"
  echo "请把补丁里 app 文件夹中的全部内容复制到：（程序名）.app/Contents/Resources/app/"
  read -r -p "按回车键关闭…"; exit 1
fi
echo "将安装补丁 v0.8.2 到：$T"
read -r -p "请先退出 FosMap 脑片活动图谱，然后按回车键开始…"
if cp -R "$D/app/." "$T/"; then
  echo; echo "补丁已安装，可以打开软件了。以后的更新可以在软件里“帮助 → 检查更新”自动完成。"
else
  echo; echo "复制失败。可以在终端里运行： sudo cp -R \"$D/app/.\" \"$T/\""
fi
read -r -p "按回车键关闭…"
