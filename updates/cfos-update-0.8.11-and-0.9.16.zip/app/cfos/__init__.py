"""Select the application for this installation's bundled dependencies."""
__version__ = "0.9.16"

import importlib.util
import os
from pathlib import Path
import sys

base = Path(os.environ["CFOS_BASE_APP"]) / "cfos" / "__init__.py"
if base.resolve() == Path(__file__).resolve():
    raise ImportError("检测到兼容补丁覆盖了安装目录。请恢复原系列的基础安装，再在“帮助 → 从文件安装补丁”中选择 ZIP。")
for line in base.read_text(encoding="utf-8").splitlines():
    if line.startswith("__version__"):
        base_version = line.partition("=")[2].strip().strip("'\"")
        break
else:
    raise ImportError("无法读取 FosFolio 安装版本")
family = ".".join(base_version.split(".")[:2])
series = {"0.7": "0.8", "0.8": "0.8", "0.9": "0.9"}.get(family)
if series is None:
    raise ImportError(f"未知的 FosFolio 安装系列：{base_version}")
app = Path(__file__).resolve().parents[1] / "_series" / series
sys.path.insert(0, str(app))
os.environ["CFOS_PATCH_APP"] = str(app)
spec = importlib.util.spec_from_file_location(__name__, app / "cfos" / "__init__.py")
package = importlib.util.module_from_spec(spec)
sys.modules[__name__] = package
spec.loader.exec_module(package)
